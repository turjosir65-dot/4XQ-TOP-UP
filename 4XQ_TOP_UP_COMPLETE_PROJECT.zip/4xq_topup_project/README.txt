4XQ TOP UP - SETUP

1) Upload the whole project folder to your Node.js hosting provider.
2) Set the start command to: npm start (or node server.js).
3) Set environment variables in hosting:
   ADMIN_EMAIL = your private admin email
   ADMIN_PASSWORD = a unique password of at least 12 characters
   PAYMENT_BKASH = your verified merchant/personal payment number
   PAYMENT_NAGAD = your verified payment number
4) Deploy. Open your website URL and create a customer account.
5) To open Admin Panel, sign in with ADMIN_EMAIL and ADMIN_PASSWORD.
6) Orders are stored in data/db.json on the server. Make sure your hosting provides persistent disk/storage. If it has ephemeral filesystem, connect a persistent database before production use.

ORDER FLOW
Customer submits an order -> Pending Verification.
Admin checks payment in their bKash/Nagad account -> Verify Payment.
Only after actual top-up delivery -> Complete Order.
Admin can Reject pending orders.

SECURITY NOTES
- Passwords are hashed with Node.js scrypt; raw passwords are not stored.
- Admin credentials are environment variables, not hardcoded in frontend.
- Session cookie is HttpOnly and SameSite=Lax.
- This starter has no payment gateway integration. TrxID is manually checked by admin.
- For a public production store, use HTTPS and a persistent database (e.g. managed PostgreSQL/Firestore), rate limiting, backups, and server-side validation. Do not expose admin credentials.
- Update package prices in server.js before accepting orders.
