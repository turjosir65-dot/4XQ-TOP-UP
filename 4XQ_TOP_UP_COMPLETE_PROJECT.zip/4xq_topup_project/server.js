'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const PORT = Number(process.env.PORT || 3000);
const ADMIN_EMAIL = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const ADMIN_PASSWORD = String(process.env.ADMIN_PASSWORD || '');
const PAYMENT_BKASH = process.env.PAYMENT_BKASH || 'Admin setup required';
const PAYMENT_NAGAD = process.env.PAYMENT_NAGAD || 'Admin setup required';
const sessions = new Map();
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], orders: [] }, null, 2));
function db(){ try{return JSON.parse(fs.readFileSync(DB_FILE,'utf8'));}catch{return {users:[],orders:[]};} }
function save(data){ const tmp=DB_FILE+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(data,null,2),{mode:0o600}); fs.renameSync(tmp,DB_FILE); }
function send(res,status,obj,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers});res.end(JSON.stringify(obj));}
function cookieToken(req){const m=(req.headers.cookie||'').match(/(?:^|; )sid=([^;]+)/);return m?decodeURIComponent(m[1]):'';}
function session(req){const s=sessions.get(cookieToken(req));if(!s||s.expires<Date.now())return null;return s;}
function setSession(res,user){const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{userId:user.id,role:user.role,expires:Date.now()+7*86400000});res.setHeader('Set-Cookie',`sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800`);}
function clearSession(req,res){sessions.delete(cookieToken(req));res.setHeader('Set-Cookie','sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');}
function hashPassword(password,salt){return crypto.scryptSync(password,salt,64).toString('hex');}
function verifyPassword(password,record){try{const actual=Buffer.from(hashPassword(password,record.salt),'hex');const expected=Buffer.from(record.hash,'hex');return actual.length===expected.length&&crypto.timingSafeEqual(actual,expected);}catch{return false;}}
function readBody(req){return new Promise((resolve,reject)=>{let raw='';req.on('data',c=>{raw+=c;if(raw.length>20000){reject(new Error('Request too large'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'));}catch{reject(new Error('Invalid JSON'));}});req.on('error',reject);});}
function safeUser(u){return {id:u.id,name:u.name,email:u.email,phone:u.phone,role:u.role};}
function requireUser(req,res,role){const s=session(req);if(!s){send(res,401,{error:'Please login'});return null;}if(role&&s.role!==role){send(res,403,{error:'Not authorized'});return null;}const u=db().users.find(x=>x.id===s.userId);if(!u){send(res,401,{error:'Session expired'});return null;}return u;}
const products=[
{id:'idcode',name:'IDCODE Topup [BD SERVER]',price:80,image:'assets/uid-topup-bd.jpg',category:'ID Topup'},
{id:'indonesia',name:'Indonesia Server [UID]',price:220,image:'assets/indonesia-server.jpg',category:'International'},
{id:'airdrop',name:'FF Ingame [Airdrop]',price:100,image:'assets/ff-likes.jpg',category:'Special'},
{id:'levelup',name:'Level Up Pass (BD Server)',price:250,image:'assets/level-up-pass.jpg',category:'Pass'},
{id:'weeklylite',name:'Weekly Lite (BD Server)',price:110,image:'assets/weekly-monthly.jpg',category:'Membership'},
{id:'weekly',name:'Weekly [BD SERVER]',price:160,image:'assets/weekly-monthly.jpg',category:'Membership'},
{id:'monthly',name:'Monthly [BD SERVER]',price:650,image:'assets/weekly-monthly.jpg',category:'Membership'},
{id:'combo',name:'Weekly + Monthly [Offer BD Server]',price:750,image:'assets/weekly-monthly.jpg',category:'Offer'}
];
async function api(req,res,url){
 if(req.method==='GET'&&url==='/api/products')return send(res,200,{products,payment:{bKash:PAYMENT_BKASH,Nagad:PAYMENT_NAGAD}});
 if(req.method==='POST'&&url==='/api/signup'){
  const b=await readBody(req);const name=String(b.name||'').trim(),email=String(b.email||'').trim().toLowerCase(),phone=String(b.phone||'').trim(),password=String(b.password||'');
  if(name.length<2||!/^\S+@\S+\.\S+$/.test(email)||phone.length<8||password.length<8)return send(res,400,{error:'Enter valid details. Password must be at least 8 characters.'});
  const d=db();if(d.users.some(u=>u.email===email))return send(res,409,{error:'Email already registered'});
  const salt=crypto.randomBytes(16).toString('hex');const u={id:crypto.randomUUID(),name,email,phone,salt,hash:hashPassword(password,salt),role:'customer',createdAt:new Date().toISOString()};d.users.push(u);save(d);setSession(res,u);return send(res,201,{user:safeUser(u)});
 }
 if(req.method==='POST'&&url==='/api/login'){
  const b=await readBody(req);const email=String(b.email||'').trim().toLowerCase(),password=String(b.password||'');let d=db();let u=d.users.find(x=>x.email===email);
  if(!u&&ADMIN_EMAIL&&email===ADMIN_EMAIL&&ADMIN_PASSWORD&&password===ADMIN_PASSWORD){u={id:'admin',name:'4XQ Administrator',email,phone:'',role:'admin'};d.users.push(u);save(d);}
  if(!u)return send(res,401,{error:'Invalid email or password'});
  if(u.role==='admin'){if(!(ADMIN_EMAIL&&email===ADMIN_EMAIL&&ADMIN_PASSWORD&&password===ADMIN_PASSWORD))return send(res,401,{error:'Invalid email or password'});}
  else if(!verifyPassword(password,u))return send(res,401,{error:'Invalid email or password'});
  setSession(res,u);return send(res,200,{user:safeUser(u)});
 }
 if(req.method==='POST'&&url==='/api/logout'){clearSession(req,res);return send(res,200,{ok:true});}
 if(req.method==='GET'&&url==='/api/me'){const u=requireUser(req,res);if(!u)return;return send(res,200,{user:safeUser(u)});}
 if(req.method==='POST'&&url==='/api/orders'){
  const u=requireUser(req,res);if(!u)return;const b=await readBody(req);const p=products.find(x=>x.id===b.productId);
  const uid=String(b.uid||'').trim(),phone=String(b.phone||'').trim(),trx=String(b.trx||'').trim(),method=String(b.payment||'');
  if(!p||uid.length<5||uid.length>30||phone.length<8||trx.length<4||!['bKash','Nagad'].includes(method))return send(res,400,{error:'Please check package, UID, phone and transaction ID'});
  const d=db();const o={id:'4XQ-'+crypto.randomBytes(4).toString('hex').toUpperCase(),userId:u.id,email:u.email,customerName:u.name,productId:p.id,product:p.name,price:p.price,uid,player:String(b.player||'').slice(0,60),region:String(b.region||'Bangladesh'),phone,payment:method,trx,status:'Pending Verification',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};d.orders.unshift(o);save(d);return send(res,201,{order:o});
 }
 if(req.method==='GET'&&url==='/api/orders'){const u=requireUser(req,res);if(!u)return;const d=db();return send(res,200,{orders:u.role==='admin'?d.orders:d.orders.filter(o=>o.userId===u.id)});}
 if(req.method==='PATCH'&&url.startsWith('/api/admin/orders/')){
  const u=requireUser(req,res,'admin');if(!u)return;const id=decodeURIComponent(url.split('/').pop());const b=await readBody(req);const allowed=['Paid - Ready for Top Up','Completed','Rejected'];if(!allowed.includes(b.status))return send(res,400,{error:'Invalid status'});
  const d=db(),o=d.orders.find(x=>x.id===id);if(!o)return send(res,404,{error:'Order not found'});
  if(b.status==='Completed'&&o.status!=='Paid - Ready for Top Up')return send(res,409,{error:'Verify payment before completing'});
  if(b.status==='Paid - Ready for Top Up'&&o.status!=='Pending Verification')return send(res,409,{error:'Only pending orders can be verified'});
  o.status=b.status;o.updatedAt=new Date().toISOString();save(d);return send(res,200,{order:o});
 }
 return send(res,404,{error:'API route not found'});
}
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml'};
const server=http.createServer(async(req,res)=>{
 try{const url=new URL(req.url,'http://localhost');if(url.pathname.startsWith('/api/'))return await api(req,res,url.pathname);
 let pathname=decodeURIComponent(url.pathname);if(pathname==='/')pathname='/index.html';const file=path.resolve(PUBLIC,'.'+pathname);if(!file.startsWith(PUBLIC+path.sep)&&file!==PUBLIC)return send(res,403,{error:'Forbidden'});
 fs.stat(file,(err,st)=>{if(err||!st.isFile()){res.writeHead(404,{'Content-Type':'text/plain'});return res.end('Not found');}res.writeHead(200,{'Content-Type':mime[path.extname(file).toLowerCase()]||'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':'no-cache'});fs.createReadStream(file).pipe(res);});
 }catch(e){send(res,400,{error:e.message||'Bad request'});}
});
server.listen(PORT,'0.0.0.0',()=>console.log(`4XQ TOP UP running on ${PORT}`));
